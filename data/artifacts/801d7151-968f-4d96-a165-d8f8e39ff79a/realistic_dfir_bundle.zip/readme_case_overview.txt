Case: Realistic DFIR Test Bundle
Host: WIN10-LAB-01
Primary user: Ramadan
Scenario: Suspicious remote logon, PowerShell download cradle, persistence via service & Run key, AV exclusions added.

Use this bundle to test:
- EVTX parsing (Security, PowerShell, System)
- Registry hive parsing for autoruns and installed apps
- Prefetch / timeline triage